'use strict';
var currentPage = 1;

function changePage(leftOrRight){
    document.getElementById("rightInfo01").style.display= "";
    document.getElementById("rightInfo02").style.display= "";
    document.getElementById("rightInfo03").style.display= "none";
    if(leftOrRight == "left"){
        currentPage -=1;
        if(currentPage === 0){
            currentPage = 1;
        }
    }else{
        currentPage +=1;
        if(currentPage === 10){
            currentPage = 9;
        }
    }
    document.getElementById("indexDiv").style.backgroundImage = "url(./images/"+currentPage+".png)";
    if(currentPage != 9){
        document.getElementById("currentPageNum").innerText = currentPage;
    }
    if(currentPage === 1){
        document.getElementById('leftImg').src="images/btn/ic_leftoff@1x.png";
        document.getElementById('rightImg').src="images/btn/ic_right@1x.png";
    }else if(currentPage === 8){
        document.getElementById('leftImg').src = "images/btn/ic_left@1x.png";
       // document.getElementById('rightImg').src = "images/btn/ic_right@1x.png";
        document.getElementById("rightInfo01").style.display= "none";
        document.getElementById("rightInfo02").style.display= "none";
        document.getElementById("rightInfo03").style.display= "";
    }else{
        document.getElementById('leftImg').src = "images/btn/ic_left@1x.png";
        document.getElementById('rightImg').src = "images/btn/ic_right@1x.png";
    }
    if(currentPage === 1 || currentPage === 9) return;
}


changePage("left");
